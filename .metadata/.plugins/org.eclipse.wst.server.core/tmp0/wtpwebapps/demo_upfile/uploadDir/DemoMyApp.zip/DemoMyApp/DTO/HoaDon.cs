﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class HoaDon
    {
        public string SoPhieu { get; set; }
        public string MaNhanVien { get; set; }
        public string MaKhachhang { get; set; }
        public DateTime NgayLapPhieu { get; set; }
        public string GhiChu { get; set; }
    }
}
